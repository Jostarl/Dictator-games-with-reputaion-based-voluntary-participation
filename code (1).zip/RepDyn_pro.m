% Reputation dynamics in the mechanism of voluntary participation
%输出声望稳态分布V（声望状态转移概率矩阵的特征值为1的归一化左特征向量的平均值）
function st_rep = RepDyn_pro(x,y,N,m,A,error,pl)
SocialNorm = A;
L = m ;
T = [1-error 0 0;error 1 0; 0 0 0];
% A_st_sn=cell(length(SocialNorm),1);
 AllReChange=[-1,0;0,-1;0,0;0,1;1,0];
%     A_st_xy=cell(4,1);
                Ix1 = [];
                Ix2 = [];
                if x(1)==1
                    Ix1 =[1; 0; 0];
                elseif x(1) == 0
                    Ix1 = [0; 1; 0];
                end
                 if x(2)==1
                    Ix2 =[1; 0 ;0];
                elseif x(2) == 0
                    Ix2 = [0; 1; 0];
                 end
                   PrBxtoGxwithG = (1-pl)*[SocialNorm(3),SocialNorm(4),0]*T*Ix1;
                   PrBxtoGxwithB = (1-pl)*[SocialNorm(7),SocialNorm(8),0]*T*Ix2;
                   PrGxtoBxwithG = [1-SocialNorm(1),1-SocialNorm(2),0]*T*Ix1;
                   PrGxtoBxwithB = [1-SocialNorm(5),1-SocialNorm(6),0]*T*Ix2;
                Iy1 = [];
                Iy2 = [];
                if y(1)==1
                    Iy1 =[1; 0 ;0];
                elseif y(1) == 0
                    Iy1 = [0 ;1 ;0];
                end
                 if y(2)==1
                    Iy2 =[1 ;0; 0];
                elseif y(2) == 0
                    Iy2 = [0; 1; 0];
                 end
                   PrBytoGywithG = (1-pl)*[SocialNorm(3),SocialNorm(4),0]*T*Iy1;
                   PrBytoGywithB = (1-pl)*[SocialNorm(7),SocialNorm(8),0]*T*Iy2;
                   PrGytoBywithG = [1-SocialNorm(1),1-SocialNorm(2),0]*T*Iy1;
                   PrGytoBywithB = [1-SocialNorm(5),1-SocialNorm(6),0]*T*Iy2;
% 
%                 A_st_rep=cell(N-1,1);
                
                    AllChangeProb=cell((L+1)*(N-L+1),1);
                    %Calculate the probabilities of all reputation change outcomes corresponding to each reputation state
                    k=1;
                    for i=0:L
                        for j=0:N-L
                            ProxBR=(L-i)/N*x(3);
                            ProyBR=(N-L-j)/N*y(3);
                            ProxGR=i/N*x(3);
                            ProyGR=j/N*y(3);
                            Prdx1_oxBR=(L-i-1)/(N-1)*((i+j)/(N-2)*PrBxtoGxwithG+(N-i-j-2)/(N-2)*PrBxtoGxwithB);
                            Prdy1_oyBR=(N-L-j-1)/(N-1)*((i+j)/(N-2)*PrBytoGywithG+(N-i-j-2)/(N-2)*PrBytoGywithB);
                            Prdx1_oyBR=(L-i)/(N-1)*((i+j)/(N-2)*PrBxtoGxwithG+(N-i-j-2)/(N-2)*PrBxtoGxwithB);
                            Prdy1_oxBR=(N-L-j)/(N-1)*((i+j)/(N-2)*PrBytoGywithG+(N-i-j-2)/(N-2)*PrBytoGywithB);
                            Prdxm1_oyBR=i/(N-1)*((i+j-1)/(N-2)*PrGxtoBxwithG+(N-i-j-1)/(N-2)*PrGxtoBxwithB);
                            Prdym1_oxBR=j/(N-1)*((i+j-1)/(N-2)*PrGytoBywithG+(N-i-j-1)/(N-2)*PrGytoBywithB);
                            Prdx1_oxGR=(L-i)/(N-1)*((i+j-1)/(N-2)*PrBxtoGxwithG+(N-i-j-1)/(N-2)*PrBxtoGxwithB);
                            Prdx1_oyGR=(L-i)/(N-1)*((i+j-1)/(N-2)*PrBxtoGxwithG+(N-i-j-1)/(N-2)*PrBxtoGxwithB);
                            Prdy1_oxGR=(N-L-j)/(N-1)*((i+j-1)/(N-2)*PrBytoGywithG+(N-i-j-1)/(N-2)*PrBytoGywithB);
                            Prdy1_oyGR=(N-L-j)/(N-1)*((i+j-1)/(N-2)*PrBytoGywithG+(N-i-j-1)/(N-2)*PrBytoGywithB);
                            Prdxm1_oxBR=i/(N-1)*((i+j-1)/(N-2)*PrGxtoBxwithG+(N-i-j-1)/(N-2)*PrGxtoBxwithB);
                            Prdym1_oyBR=j/(N-1)*((i+j-1)/(N-2)*PrGytoBywithG+(N-i-j-1)/(N-2)*PrGytoBywithB);
                            Prdxm1_oxGR=(i-1)/(N-1)*((i+j-2)/(N-2)*PrGxtoBxwithG+(N-i-j)/(N-2)*PrGxtoBxwithB);
                            Prdxm1_oyGR=i/(N-1)*((i+j-2)/(N-2)*PrGxtoBxwithG+(N-i-j)/(N-2)*PrGxtoBxwithB);
                            Prdym1_oxGR=j/(N-1)*((i+j-2)/(N-2)*PrGytoBywithG+(N-i-j)/(N-2)*PrGytoBywithB);
                            Prdym1_oyGR=(j-1)/(N-1)*((i+j-2)/(N-2)*PrGytoBywithG+(N-i-j)/(N-2)*PrGytoBywithB);



                            Pr1=Prdxm1_oxGR*ProxGR+Prdxm1_oyGR*ProyGR+Prdxm1_oxBR*ProxBR+Prdxm1_oyBR*ProyBR;
                            Pr4=Prdym1_oxGR*ProxGR+Prdym1_oyGR*ProyGR+Prdym1_oxBR*ProxBR+Prdym1_oyBR*ProyBR;
                            Pr6=Prdy1_oxGR*ProxGR+Prdy1_oyGR*ProyGR+Prdy1_oxBR*ProxBR+Prdy1_oyBR*ProyBR;
                            Pr9=Prdx1_oxGR*ProxGR+Prdx1_oyGR*ProyGR+Prdx1_oxBR*ProxBR+Prdx1_oyBR*ProyBR;
                            Pr5=1-(Pr1+Pr4+Pr6+Pr9);
                            AllChangeProb(k,1)={[Pr1;Pr4;Pr5;Pr6;Pr9]};
                            k=k+1;
                        end
                    end

                %Enumerate all possible reputation states.
                AllReputationStates=zeros((L+1)*(N-L+1),2);
                k2=1;
                for i=0:L
                    for j=0:N-L
                        AllReputationStates(k2,:)=[i,j];
                        k2=k2+1;
                    end
                end

                %Matrix of reputation transition probabilities.
                ReputationTransitionMatrix=zeros((L+1)*(N-L+1));
                k3=1;
                for i=0:L
                    for j=0:(N-L)
                        currentReputationState=[i,j];
                        ChangeProb=AllChangeProb{k3,:};
                        for m=1:(L+1)*(N-L+1)
                             if m==k3
                                 ReputationTransitionMatrix(k3,m)=0;
                             else
                                Temp=AllReputationStates(m,:)-currentReputationState;
                                flag=0;
                                for ind=1:5
                                     if (Temp(1)==AllReChange(ind,1))&&(Temp(2)==AllReChange(ind,2))
                                         flag=ind;
                                     end
                                end
                                if flag==0
                                     ReputationTransitionMatrix(k3,m)=0;
                                else
                                    ReputationTransitionMatrix(k3,m)=ChangeProb(flag);
                                end
                             end
                        end
                        k3=k3+1;
                    end
                end



                for q=1:(L+1)*(N-L+1)
                    ReputationTransitionMatrix(q,q)=1-sum(ReputationTransitionMatrix(q,:));
                end
             P = ReputationTransitionMatrix;
                

                [eigenVec,eigenVal]=eig(P');
                [~,one_val]=find(abs(eigenVal-1)<1e-5);
                time_per_=eigenVec(:,one_val);
                %Normalize the obtained feature vector.
                for p1=1:size(time_per_,2)
                    time_per_(:,p1)=time_per_(:,p1)/sum(time_per_(:,p1));
                end
                time_per_=round(time_per_*1e4)/1e4; 
                %Record the number of vectors with negative values in the normalized feature vectors.
                flag_an=0;
                for p2=1:size(time_per_,2)
                    for p3=1:size(time_per_,1)
                        if time_per_(p3,p2)<0
                            flag_an=flag_an+1;
                            break
                        end
                    end
                end
                %If all the feature vectors obtained are normalized and still contain negative values, handle the case separately for vectors without complex parts and for vectors with complex parts
                %Otherwise, select the one with the smallest row number of the maximum element among all the feature vectors that do not contain negative values
                %"time_per" is the final sought feature vector.
                if flag_an==size(time_per_,2)
                    if all(imag(time_per_)==0)
                        time_per=time_per_(:,1)+time_per_(:,2);
                    else
                        time_per=time_per_(:,1).*time_per_(:,2);
                    end
                    time_per=time_per/sum(time_per);
                else
                    for p4=1:size(time_per_,2)
                        for p5=1:size(time_per_,1)
                            if time_per_(p5,p4)<0
                                time_per_(:,p4)=zeros(size(time_per_,1),1);
                                break
                            end
                        end
                    end
                    time_per_(:,all(time_per_==0,1))=[];
                    M_mp=zeros(size(time_per_,2),2); 
                    for p6=1:size(time_per_,2)
                        [m,p]=max(time_per_(:,p6));
                        M_mp(p6,:)=[m,p];
                    end
                    [m_1,p_1]=max(M_mp(:,1));
                    if m_1==1 && M_mp(p_1,2)==1
                        time_per=time_per_(:,p_1);
                    else
                        [~,p_2]=min(M_mp(:,2));
                        time_per=time_per_(:,p_2);
                    end
                end
                st_rep =  time_per';
end