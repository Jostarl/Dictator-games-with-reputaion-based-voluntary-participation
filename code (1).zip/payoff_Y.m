%the payoff of Y in the specific reputation state
function PIy = payoff_Y(N,m,i,j,x,y,e,pl)
% sigma = 0.1;
% Cr = 0.1;

px = 0.01;
if x(1) == 0
    NxG = 1; FxG = 0; 
elseif x(1) == 1
    NxG = 0; FxG = 1; 
else 
    NxG = 0; FxG = 0; 
end

if x(2) == 0
    NxB = 1; FxB = 0;
elseif x(2) == 1
    NxB = 0; FxB = 1; 
else 
    NxB = 0; FxB = 0;
end

if y(1) == 0
    NyG = 1; FyG = 0; 
elseif y(1) == 1
    NyG = 0; FyG = 1; 
else 
    NyG = 0; FyG = 0; 
end

if y(2) == 0
    NyB = 1; FyB = 0; 
elseif y(2) == 1
    NyB = 0; FyB = 1; 
else 
    NyB = 0; FyB = 0; 
end
Z = N;

%the Y-player was selected as a dictator and take fair action
P_DF = 0.5*(1-e)*(j/(Z-m)*(0.5*FyG*(i+j-1)/(Z-1)+0.5*FyB*(Z-i-j)/(Z-1))+(Z-m-j)/(Z-m)*(1-pl)*(0.5*FyG*(i+j)/(Z-1)+0.5*FyB*(Z-1-i-j)/(Z-1)));
%the Y-player was selected as a dictator and take unfair action
P_DN = (1-px)*(0.5*j/(Z-m)*((NyG+e*FyG)*(i+j-1)/(Z-1)+(NyB+e*FyB)*(Z-i-j)/(Z-1))+0.5*(1-pl)*(Z-m-j)/(Z-m)*((NyG+e*FyG)*(i+j)/(Z-1)+(NyB+e*FyB)*(Z-i-j-1)/(Z-1)));
% P_DL = 0*sigma*0.5*pl*(Z-m-j)/(Z-m);
%the Y-player was selected as a recipient and the dictator take fair action
P_RF = 0.5*(1-e)*(j/(Z-m)*0.5*(FxG*i/(Z-1)+(1-pl)*FxG*(m-i)/(Z-1)+FyG*(j-1)/(Z-1)+FyG*(1-pl)*(Z-m-j)/(Z-1)))+0.5*(1-e)*((Z-m-j)/(Z-m)*0.5*(FxB*i/(Z-1)+(1-pl)*FxB*(m-i)/(Z-1)+FyB*j/(Z-1)+(1-pl)*FyB*(Z-m-j-1)/(Z-1)));
%the Y-player was selected as a recipient and the dictator take unfair action
P_RN = px*(0.5*j/(Z-m)*((NxG+e*FxG)*i/(Z-1)+(1-pl)*(NxG+e*FxG)*(m-i)/(Z-1)+(NyG+e*FyG)*(j-1)/(Z-1)+(NyG+e*FyG)*(1-pl)*(Z-m-j)/(Z-1))+0.5*(Z-m-j)/(Z-m)*((NxB+e*FxB)*i/(Z-1)+(NxB+e*FxB)*(1-pl)*(m-i)/(Z-1)+(NyB+e*FyB)*j/(Z-1)+(NyB+e*FyB)*(1-pl)*(Z-m-j-1)/(Z-1)));
% P_RL = 0*0.5*sigma*pl*(j/(Z-m)*(Z-i-j)/(Z-1)+(Z-m-j)/(Z-m)*(Z-i-j-1)/(Z-1));
PIy = P_DF+P_DN+P_RF+P_RN;

end