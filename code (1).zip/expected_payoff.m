%Expected payoff gx(m),gy(m)
function [gx_m,gy_m] = expected_payoff(x,y,N,m,error,time_per,pl)
    %Calculate the payoff corresponding to each reputation state
    payoffX = zeros((m+1)*(N-m+1),1);
    payoffY = zeros((m+1)*(N-m+1),1);
    k1 = 1;
    for i = 0:m
        for j = 0:N-m
            if m>0 
                payoffX(k1) = payoff_X(N,m,i,j,x,y,error,pl);
            else
                payoffX(k1) = 0;
            end
            if N-m>0
                payoffY(k1) = payoff_Y(N,m,i,j,x,y,error,pl);
            else
                payoffY(k1) = 0;
            end
            k1 = k1+1;
        end
    end


    %Calculate the payoff for strategies X and Y under a fixed strategy distribution.
    gx_m = time_per*payoffX;
    gy_m = time_per*payoffY;

end