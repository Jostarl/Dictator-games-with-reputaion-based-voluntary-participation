%theoretical simulation
clc;clear
time_start = datetime;
N = 50; % population size
Strategies = [];
ALL = zeros(256,256);
PFN = zeros(256,256);
for i = 1:2
    for j = 1:2
        for k = 1:1
        Strategies = [Strategies;i-1 j-1 k];    
        end
    end
end
% Strategies = [0 0 0; 0 0 1; 0 1 0; 0 1 1; 1 0 0; 1 0 1; 1 1 0; 1 1 1];
error = 0.01; % error
selection_intensity = 1; % selection_intensity

soci = [165 167 173 141 133 135 175 181 143 183 149 151 157 189 191 159];
for tt = 1:16 %16 social norms that can promote the level of fairness when recipients act with voluntary participation
SocialNorm_1=bitget(soci(tt) , 8:-1:1);   
station = zeros(18,4);
invade = zeros(2,18);
for ii = 1:12 %different selection_intensity
%     soc = soci(ii);
if ii == 1
    selection_intensity = 0.01;
elseif ii == 2
        selection_intensity = 0.1;
    else
        selection_intensity = ii-2;
end
fprintf('social norm: ') 
fprintf('%d%d%d%d%d%d%d%d\n',SocialNorm_1) 
Matrix_rho = zeros(4); %matrix of fixation probability
pl = 0.5; % probablity of voluntary participation

test = zeros(N-1,2,4,4);
for i = 1:4
    for j = 1:4
        payx = zeros(N-1,1);
        payy = zeros(N-1,1);
        pay = zeros(N-1,2);
        if i == j
            Matrix_rho(i,j) = 0;
        else
            [Matrix_rho(i,j),payy,payx] = ProFix_pro(Strategies(j,:),Strategies(i,:),...
                N,error,SocialNorm_1,selection_intensity,pl);
            pay = [payx,payy];
            test( : , : ,i,j) = pay;
        end
    end
end
% invade(1,ii) = Matrix_rho(1,3);
% invade(2,ii) = Matrix_rho(3,1);
time_end = datetime;
time_ = time_end-time_start;
fprintf('Run_Time:');
fprintf(datestr(time_, 13));
fprintf('\n');

tran_stra = zeros(4);
mut = 0.01; %mutation rate
sum_prob = zeros(4,1);
% transition matrix
for i = 1:4
    for j = 1:4
        if i ~= j 
            tran_stra(i,j) = mut*Matrix_rho(i,j)/4;
            sum_prob(i,1) = sum_prob(i,1)+tran_stra(i,j);
        end
    end
end
for i = 1:4
    tran_stra(i,i) = 1-sum_prob(i,1);
end

% [V,D] = eig(tran_stra');
% [~,index] = find(abs(D-1)<1e-5);
% st_stra = V(:,index);
% st_stra = st_stra / sum(st_stra);
% st_stra = st_stra';
                [eigenVec,eigenVal]=eig(tran_stra');
                [~,one_val]=find(abs(eigenVal-1)<1e-5);
                time_per_=eigenVec(:,one_val);
                %Normalize the obtained feature vectors
                for p1=1:size(time_per_,2)
                    time_per_(:,p1)=time_per_(:,p1)/sum(time_per_(:,p1));
                end
                time_per_=round(time_per_*1e4)/1e4; %Keep the results to four decimal places
                %Record the number of vectors with negative values in the normalized feature vectors
                flag_an=0;
                for p2=1:size(time_per_,2)
                    for p3=1:size(time_per_,1)
                        if time_per_(p3,p2)<0
                            flag_an=flag_an+1;
                            break
                        end
                    end
                end
                %If all the feature vectors obtained are normalized and still contain negative values, handle the case separately for vectors without complex parts and for vectors with complex parts
                %Otherwise, select the one with the smallest row number of the maximum element among all the feature vectors that do not contain negative values
                %"time_per" is the final sought feature vector.
                if flag_an==size(time_per_,2)
                    if all(imag(time_per_)==0)
                        time_per=time_per_(:,1)+time_per_(:,2);
                    else
                        time_per=time_per_(:,1).*time_per_(:,2);
                    end
                    time_per=time_per/sum(time_per);
                else
                    for p4=1:size(time_per_,2)
                        for p5=1:size(time_per_,1)
                            if time_per_(p5,p4)<0
                                time_per_(:,p4)=zeros(size(time_per_,1),1);
                                break
                            end
                        end
                    end
                    time_per_(:,all(time_per_==0,1))=[];
                    M_mp=zeros(size(time_per_,2),2); 
                    for p6=1:size(time_per_,2)
                        [m,p]=max(time_per_(:,p6));
                        M_mp(p6,:)=[m,p];
                    end
                    [m_1,p_1]=max(M_mp(:,1));
                    if m_1==1 && M_mp(p_1,2)==1
                        time_per=time_per_(:,p_1);
                    else
                        [~,p_2]=min(M_mp(:,2));
                        time_per=time_per_(:,p_2);
                    end
                end
PFN(tt,ii) = time_per(3,1);
station(ii,:) = time_per;
st_stra = time_per';
%calculate the level of fairness               
FF =zeros(256,1);
FN = zeros(256,1);
FL = zeros(256,1);
fF = zeros(4,1);
fN = zeros(4,1);
fL = zeros(4,1);
for i = 1 : 4
if Strategies(i,1) == 0
    NxG = 1; FxG = 0; 
elseif Strategies(i,1) == 1
    NxG = 0; FxG = 1; 
else 
    NxG = 0; FxG = 0; 
end

if Strategies(i,2) == 0
    NxB = 1; FxB = 0; 
elseif Strategies(i,2) == 1
    NxB = 0; FxB = 1; 
else 
    NxB = 0; FxB = 0; 
end

% if i == 1
%     fF(i,1) = 0;
% elseif i == 5
%     fF(i,1) = 1-error;
% elseif i == 9
%     fF(i,1) = fL;
% else
   sta_per = RepDyn_pro(Strategies(i, : ),Strategies(i, : ),N,N,SocialNorm_1,error,pl);
   pF = 0;
   pN = 0;
%    pL = 0;
   for j =0:N
      pF = (1-error)*FxG*j/N+(1-error)*FxB*(N-j)/N;
      pN = (NxG+error*FxG)*j/N+(NxB+error*FxB)*(N-j)/N;
%       pL = LxG*j/N+LxB*(N-j)/N;
      fF(i,1) = fF(i,1)+pF*sta_per(j+1) ;
      fN(i,1) = fN(i,1)+pN*sta_per(j+1) ;
%       fL(i,1) = fL(i,1)+pL*sta_per(j+1) ;
   end
% end

FF(ii,1) = FF(ii,1) + st_stra(i)*fF(i,1);
FN(ii,1) = FN(ii,1) + st_stra(i)*fN(i,1);
% FL(ii,1) = FL(ii,1) + st_stra(i)*fL(i,1);
end

        ALL(tt,ii) = FF(ii,1);

  

end
stat = station';
% for i = 1:256
%     for jj = 1:11
%         ALL(tt,i) = FF(i,1);
% 
%     end
% end

end