%Proposer-based reputation update
%Calculate the fixation probability of strategy X in the group full of strategy Y
function [stationarypro,payx,payy]= ProFix_pro(x,y,N,error,A,beta,pl)
Tpos = zeros(N-1,1);
Tneg = zeros(N-1,1);
payx = zeros(N-1,1);
payy = zeros(N-1,1);
for L = 1:N-1
    time_per = RepDyn_pro(x,y,N,L,A,error,pl);
    [fx,fy] = expected_payoff(x,y,N,L,error,time_per,pl);
    %T+和T-
    payx(L,1) = fx;
    payy(L,1) = fy;
    Tpos(L) = (N-L)/N*L/(N-1)/(1+exp(-beta*(fx-fy)));
    Tneg(L) = L/N*(N-L)/(N-1)/(1+exp(-beta*(fy-fx)));
end

stationarypro = 0;
for k = 1:N-1
    q = 1;
    for l = 1:k
        q = q*(Tneg(l)/Tpos(l));
    end
    stationarypro = stationarypro+q;
end
stationarypro = 1/(1+stationarypro);
end
